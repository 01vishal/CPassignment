#include<iostream>
using namespace std;
int sum(int a, int b){
    cout<<"sum of two digit are:";
    return a+b;
}
int main(){
    cout<<sum(5,7);
    return 0;
}
