#include<iostream>
using namespace std;
void printingstuff(){
    cout<<"helloo!! this is my first fuction";
}
int main(){
    printingstuff();
    return 0;
}
