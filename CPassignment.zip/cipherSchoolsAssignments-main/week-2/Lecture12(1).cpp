#include <iostream>
using namespace std;
int main(){
    int a;
    float b;
    cout<<"the address of a is : "<<&a<<endl;
    cout<<"the address of a is : "<<&b<<endl;
    return 0;
}
