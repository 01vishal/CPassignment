#include<iostream>
using namespace std;
int main(){
    long long int a;
    cout<<"the size of int is :"<<sizeof(int)<<endl;
    cout<<"the size of int is :"<<sizeof(a)<<endl;
    return 0;
}
