#include <bits/stdc++.h>
using namespace std;
int main(){
//Postfix and Prefix increament
	int i,j,k;
	i=0;
	j=0;
	k=0;
	
	cout<<i<<" "<<j<<" "<<k<<endl;
	j=i++;
	cout<<i<<" "<<j<<" "<<k<<endl;
	k=++i;
	cout<<i<<" "<<j<<" "<<k<<endl;
}
