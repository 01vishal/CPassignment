//lec 2
#include <iostream>
using namespace std;
int main() {
    //commentsss: ignored by compiler

    cout << "Hello world!";

    return 0;
}
