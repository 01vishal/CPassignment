//lec 5-I
#include <iostream>
using namespace std;
int main(){
    int a,b,c,d,e;
    cin>>a>>b>>c>>d>>e;
    cout<<"numbers in reverse"<<e<<d<<c<<b<<a;
    return 0;
}
