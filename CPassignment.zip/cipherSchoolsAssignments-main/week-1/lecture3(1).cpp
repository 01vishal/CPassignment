
#include<iostream>
using namespace std;
int main(){
    int a=3;
    int b=5;
    cout<<"a+b"<<endl<<a+b;
    return 0;
}
